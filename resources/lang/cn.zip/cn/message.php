<?php

   return [

   				'captcha_error'  =>'验证码不正确',
   				'user_or_password_error'=>'用户名或者密码错误',

   ];