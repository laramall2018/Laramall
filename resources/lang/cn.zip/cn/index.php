<?php
/**
 * Created by PhpStorm.
 * User: swh
 * Date: 15/12/29
 * Time: 上午10:09
 */

return [


    'title'         => '全网首款基于Laravel框架的商城系统phpstore',



];