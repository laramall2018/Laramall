<?php

return [
			
			'back_activity_list'			=>'返回活动列表',
			'activity_list'					=>'活动列表',
			'add_activity'					=>'添加活动',
			'edit_activity'					=>'编辑活动',
			'formula_list'					=>'公式列表',
			'add_formula'					=>'添加公式',
			'edit_formula'					=>'编辑公式',
			'add_config'					=>'系统设置',
			'order_list'					=>'订单列表',
			'add_order'						=>'添加订单',


];