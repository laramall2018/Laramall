<?php

return[
		
		'batch_add_privi'					=>'批量添加权限',


];