<?php

return [

		
		'add_goods' 					=>'添加商品',
		'select_formula'				=>'请选择返利规则',
		'type_list'						=>'商品类型列表',
		'add_type'						=>'添加商品类型',
		'add_attr'						=>'添加商品属性',
		'attr_list'						=>'商品属性列表',
		'field_list'					=>'商品字段列表',
		'add_field'						=>'添加商品字段',
];